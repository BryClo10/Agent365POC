"""Read-only check of a deployed Vertex AI Agent Engine agent against the Agent 365 runbook.

Usage:
    python diagnose.py <agent name or resource name> [federated credential subject]

Examples:
    python diagnose.py vertex-policy-helper
    python diagnose.py projects/123/locations/us-central1/reasoningEngines/456 110119968816370067218

Checks that the agent runs as a named service account, that the service account is the one the
Entra blueprint trusts, that the Agent 365 settings and bridge were deployed with it, and what
the bridge logged in the last 24 hours. Changes nothing.
"""

import io
import pathlib
import sys
import tarfile

import google.auth
import google.auth.transport.requests
import requests

RESOURCE = sys.argv[1]
if not RESOURCE.startswith("projects/"):
    saved = pathlib.Path(__file__).parent / "deployments" / f"{RESOURCE}.txt"
    if not saved.exists():
        sys.exit(f"No saved resource name for '{RESOURCE}'. Pass the full resource name instead.")
    RESOURCE = saved.read_text().strip()
EXPECTED_SUBJECT = sys.argv[2] if len(sys.argv) > 2 else None
_, PROJECT_NUM, _, LOCATION, _, ENGINE_ID = RESOURCE.split("/")

creds, _ = google.auth.default(scopes=["https://www.googleapis.com/auth/cloud-platform"])
creds.refresh(google.auth.transport.requests.Request())
H = {"Authorization": f"Bearer {creds.token}"}
problems = []


def get(url, **kw):
    r = requests.get(url, headers=H, timeout=30, **kw)
    return r.status_code, (r.json() if "json" in r.headers.get("content-type", "") else r.content)


def report(ok, text):
    print(("  OK    " if ok else "  FAIL  ") + text)
    if not ok:
        problems.append(text)


print(f"\nAgent {RESOURCE}")
code, eng = get(f"https://{LOCATION}-aiplatform.googleapis.com/v1/{RESOURCE}")
if code != 200:
    sys.exit(f"Cannot read the agent (HTTP {code}). Check the resource name and your access. {eng}")
spec = eng.get("spec", {})
print(f"  Name: {eng.get('displayName')}   Updated: {eng.get('updateTime')}")

print("\n1. Service account the agent runs as")
sa = spec.get("serviceAccount")
if not sa:
    report(False, "No service account set, so the agent runs as Google's default Agent Engine service agent. "
                  "Deploy with service_account set to your runtime service account (runbook step 1 and deploy.py).")
else:
    print(f"  Service account: {sa}")
    code, acct = get(f"https://iam.googleapis.com/v1/projects/-/serviceAccounts/{sa}")
    uid = acct.get("uniqueId") if code == 200 else None
    print(f"  Unique ID: {uid or f'unreadable (HTTP {code})'}")
    if not EXPECTED_SUBJECT:
        print("  This number must match the Subject identifier of the blueprint's federated credential (runbook step 5).")
    if EXPECTED_SUBJECT:
        report(uid == EXPECTED_SUBJECT,
               f"Unique ID matches the blueprint's federated credential subject ({EXPECTED_SUBJECT})")

print("\n2. Agent 365 settings deployed with the agent")
env = {e["name"]: e.get("value", "") for e in spec.get("deploymentSpec", {}).get("env", [])}
for key in ("A365_TENANT_ID", "A365_BLUEPRINT_ID", "A365_AGENT_ID", "A365_AUTH_MODE"):
    report(key in env, f"{key} = {env.get(key, 'missing')}")
report(env.get("A365_ENFORCE_IDENTITY", "").lower() == "true",
       f"A365_ENFORCE_IDENTITY = {env.get('A365_ENFORCE_IDENTITY', 'missing')} (needed for the kill switch test)")
report(env.get("A365_REQUIRE_USER", "").lower() == "true",
       f"A365_REQUIRE_USER = {env.get('A365_REQUIRE_USER', 'missing')} (callers must sign in with Entra)")
print(f"  INFO  A365_PURVIEW = {env.get('A365_PURVIEW', 'missing')} (true = Microsoft Purview checks prompts and answers)")

print("\n3. Bridge code packaged with the agent")
uri = spec.get("packageSpec", {}).get("dependencyFilesGcsUri")
if not uri:
    report(False, "No extra packages were deployed with the agent")
else:
    bucket, _, obj = uri[len("gs://"):].partition("/")
    code, blob = get(f"https://storage.googleapis.com/storage/v1/b/{bucket}/o/{requests.utils.quote(obj, safe='')}",
                     params={"alt": "media"})
    if code != 200:
        report(False, f"Cannot read {uri} (HTTP {code})")
    else:
        names = tarfile.open(fileobj=io.BytesIO(blob)).getnames()
        report(any("a365_vertex_bridge/bridge.py" in n for n in names),
               f"a365_vertex_bridge found in {uri.rsplit('/', 1)[-1]}")

print("\n4. What the bridge logged in the last 24 hours")
flt = (f'resource.labels.reasoning_engine_id="{ENGINE_ID}" AND '
       '("identity_check" OR "user_check" OR "purview_check" OR "obo_token_acquired" OR "workiq_tools" '
       'OR "telemetry_sent" OR "telemetry_error" OR "missing env var")')
r = requests.post("https://logging.googleapis.com/v2/entries:list", headers=H, timeout=30, json={
    "resourceNames": [f"projects/{PROJECT_NUM}"],
    "filter": flt + ' AND timestamp>="' + __import__("datetime").datetime.utcfromtimestamp(
        __import__("time").time() - 86400).strftime("%Y-%m-%dT%H:%M:%SZ") + '"',
    "orderBy": "timestamp desc", "pageSize": 12})
entries = r.json().get("entries", []) if r.ok else []
if not r.ok:
    report(False, f"Cannot read Cloud Logging (HTTP {r.status_code})")
elif not entries:
    report(False, "No bridge activity. Either the agent was not queried, or it was deployed without the bridge.")
for e in entries:
    p = e.get("jsonPayload") or {"text": e.get("textPayload", "")}
    print(f"  {e['timestamp'][:19]}Z  {p}"[:400])

print("\nResult: " + ("everything checked out." if not problems else f"{len(problems)} problem(s) found."))
for p in problems:
    print(f"  - {p}")
