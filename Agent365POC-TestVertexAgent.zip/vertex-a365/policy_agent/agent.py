"""Second test agent: a travel-policy helper that was deployed to Vertex AI *before*
anyone thought about Agent 365. Used to prove the discover-then-onboard runbook."""

from google.adk.agents import Agent

_LIMITS = {
    "hotel": {"limit_usd": 250, "per": "night"},
    "meals": {"limit_usd": 75, "per": "day"},
    "flight": {"limit_usd": 800, "per": "trip", "note": "economy only for flights under 6 hours"},
    "car": {"limit_usd": 90, "per": "day"},
}


def lookup_travel_limit(category: str) -> dict:
    """Look up the company travel expense limit for a category: hotel, meals, flight or car."""
    return _LIMITS.get(category.lower().strip(), {"error": f"unknown category '{category}'"})


root_agent = Agent(
    name="vertex_policy_helper",
    model="gemini-2.5-flash",
    description="Answers questions about travel expense limits.",
    instruction=(
        "You answer travel expense policy questions. Always call lookup_travel_limit "
        "for the relevant category and quote the limit in one short sentence. "
        "If mail tools are available and the user asks you to email or look up mail, use them "
        "for the signed-in user."
    ),
    tools=[lookup_travel_limit],
)
