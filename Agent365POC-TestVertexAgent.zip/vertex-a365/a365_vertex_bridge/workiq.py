"""Work IQ MCP tools for an ADK agent, called through the Microsoft Agent 365 tooling gateway.

The agent calls each tool as its Entra agent identity acting for the signed-in user
(on-behalf-of), so the gateway applies the tenant's tool policies and Microsoft Defender
real-time protection evaluates each invocation before it runs.

Add it to an agent with the servers from the agent's ToolingManifest.json
(written by `a365 develop add-mcp-servers`):

    from a365_vertex_bridge.workiq import WorkIQToolset
    root_agent.tools.append(WorkIQToolset(manifest["mcpServers"]))

Callers without a verified Entra user token get no Work IQ tools.
"""

import asyncio
import time

from google.adk.tools.base_toolset import BaseToolset

from .bridge import _log

# Filled in per request by A365AdkApp: user object ID -> (Caller, EntraAgentIdentity, bound_at).
_CALLERS = {}
# Tool name -> MCP server name, so telemetry can label these calls as MCP tools.
MCP_TOOLS = {}


def bind(caller, identity):
    _CALLERS[caller.oid] = (caller, identity, time.time())


class WorkIQToolset(BaseToolset):
    def __init__(self, servers):
        super().__init__()
        self._servers = [dict(s) for s in servers]
        self._toolsets = None  # built on first use, on the server (MCP sessions can't be pickled)

    def __getstate__(self):
        state = dict(self.__dict__)
        state["_toolsets"] = None
        return state

    def _build(self):
        from google.adk.tools.mcp_tool.mcp_session_manager import StreamableHTTPConnectionParams
        from google.adk.tools.mcp_tool.mcp_toolset import McpToolset

        toolsets = []
        for server in self._servers:
            scope = f"{server['audience']}/.default"

            async def headers(ctx, scope=scope):
                caller, identity, _ = _CALLERS[ctx.user_id]
                token = await asyncio.to_thread(identity.obo_token, caller, scope)
                return {"Authorization": f"Bearer {token}"}

            toolsets.append((server, McpToolset(
                connection_params=StreamableHTTPConnectionParams(url=server["url"], timeout=30),
                header_provider=headers)))
        return toolsets

    async def get_tools(self, readonly_context=None):
        user = getattr(readonly_context, "user_id", None)
        if not user or user not in _CALLERS:
            _log("workiq_tools", result="none", reason="caller has no verified Entra user token")
            return []
        if self._toolsets is None:
            self._toolsets = self._build()
        tools = []
        for server, toolset in self._toolsets:
            try:
                found = await toolset.get_tools(readonly_context)
            except Exception as exc:
                _log("workiq_tools", server=server["mcpServerName"], result="error", error=str(exc)[:300])
                continue
            for tool in found:
                MCP_TOOLS[tool.name] = server["mcpServerName"]
            tools += found
        return tools

    async def close(self):
        for _, toolset in self._toolsets or []:
            await toolset.close()
