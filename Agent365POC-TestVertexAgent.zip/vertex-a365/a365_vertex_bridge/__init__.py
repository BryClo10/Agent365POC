"""Microsoft Agent 365 bridge for Google ADK agents on Vertex AI Agent Engine.

Onboarding an existing ADK agent is a one-line change:

    from a365_vertex_bridge import A365AdkApp      # instead of vertexai.agent_engines.AdkApp
    app = A365AdkApp(agent=root_agent)

plus the A365_* environment variables documented in bridge.py, and adding this
folder to the deployment's extra_packages.
"""

from .app import A365AdkApp  # noqa: F401
