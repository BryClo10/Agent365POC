"""AdkApp subclass that runs every query as the agent's Entra identity, for a verified Entra user,
under Microsoft Purview policies, and reports it to Agent 365."""

import asyncio
import json
import uuid

from vertexai.agent_engines import AdkApp

from . import workiq
from .bridge import EntraAgentIdentity, PurviewGuard, RunRecorder, UserVerifier, _log, flag

REFUSAL = ("This agent is currently disabled by your organization's Microsoft Agent 365 / Entra administrator, "
           "so it can't answer right now.")
SIGN_IN_REFUSAL = ("This agent needs to know who you are. Sign in with your work account "
                   "(send a Microsoft Entra access token for this agent) and try again.")
PURVIEW_REFUSAL = ("Your message was blocked by your organization's data protection policy "
                   "(Microsoft Purview). Remove the sensitive information and try again.")
PURVIEW_RESPONSE_REFUSAL = ("The agent's answer was blocked by your organization's data protection policy "
                            "(Microsoft Purview).")
FILES_REFUSAL = ("Attachments can't be checked by your organization's data protection policy yet, "
                 "so this agent only accepts text. Paste the text instead.")


def _text(message) -> str:
    if isinstance(message, str):
        return message
    parts = (message or {}).get("parts", []) if isinstance(message, dict) else []
    return " ".join(p.get("text", "") for p in parts if isinstance(p, dict)).strip()


def _has_attachments(message) -> bool:
    parts = (message or {}).get("parts", []) if isinstance(message, dict) else []
    return any(isinstance(p, dict) and any(p.get(k) for k in ("inline_data", "inlineData", "file_data", "fileData"))
               for p in parts)


def _refusal_event(session_id, text):
    return {"author": "a365_gate", "session_id": session_id,
            "content": {"role": "model", "parts": [{"text": text}]}}


class _Turn:
    """Everything the bridge knows about one query."""

    def __init__(self, user_id, session_id):
        self.user_id = user_id
        self.session_id = session_id
        self.caller = None
        self.rec = None
        self.guard = None
        self.sequence = 0
        self.refusal = None
        self.hold_response = False  # Purview wants the answer checked before the user sees it

    def observe(self, event):
        if self.rec:
            self.rec.observe(event)


class A365AdkApp(AdkApp):
    """Drop-in replacement for AdkApp: same operations, plus
      - A365_ENFORCE_IDENTITY=true: an Entra identity check before every run (kill switch),
      - user_token: the caller's Entra access token for the agent, verified on every query,
        A365_REQUIRE_USER=true refuses callers without one,
      - A365_PURVIEW=true: Microsoft Purview checks on prompts and responses,
      - Work IQ MCP tools (see workiq.py) called on behalf of the verified user,
      - Agent 365 telemetry for every run."""

    # --- lazily built per worker (environment variables exist on the server, not at pickling time)

    def _a365_identity(self):
        ident = getattr(self, "_a365_ident", None)
        if ident is None:
            try:
                ident = EntraAgentIdentity()
            except KeyError as missing:
                _log("disabled", reason=f"missing env var {missing}")
                ident = False
            self._a365_ident = ident
        return ident or None

    def _purview(self, ident):
        if not (flag("A365_PURVIEW") and ident):
            return None
        guard = getattr(self, "_a365_purview", None)
        if guard is None:
            guard = self._a365_purview = PurviewGuard(ident)
        return guard

    def _verify(self, ident, token):
        verifier = getattr(self, "_a365_verifier", None)
        if verifier is None:
            verifier = self._a365_verifier = UserVerifier(ident)
        return verifier.verify(token)

    def _next_sequence(self, session_id):
        seqs = getattr(self, "_a365_seq", None)
        if seqs is None:
            seqs = self._a365_seq = {}
        seqs[session_id] = seqs.get(session_id, -1) + 1
        return seqs[session_id]

    def _gate(self, ident) -> bool:
        if not flag("A365_ENFORCE_IDENTITY"):
            return True
        return bool(ident) and ident.authorize()

    # --- before and after every query (blocking network calls; async paths run them in a thread)

    def _before(self, user_id, user_token, session_id, message, channel, create_session):
        turn = _Turn(user_id, session_id)
        ident = self._a365_identity()
        if not self._gate(ident):
            turn.refusal = REFUSAL
            return turn
        if user_token and ident:
            try:
                turn.caller = self._verify(ident, user_token)
            except Exception as exc:
                _log("user_check", result="rejected", error=str(exc)[:300])
                turn.refusal = SIGN_IN_REFUSAL
                return turn
            if user_id and user_id != turn.caller.oid:
                _log("user_check", note="user_id replaced by the verified token's object ID")
            turn.user_id = turn.caller.oid
            _log("user_check", result="verified", user=turn.caller.oid)
        elif flag("A365_REQUIRE_USER"):
            _log("user_check", result="rejected", error="no user token")
            turn.refusal = SIGN_IN_REFUSAL
            return turn

        if not turn.session_id and create_session:
            turn.session_id = create_session(turn.user_id)
        text = _text(message)
        turn.rec = RunRecorder(ident, turn.caller, turn.session_id, text, channel=channel,
                               mcp_tools=workiq.MCP_TOOLS) if ident else None
        turn.guard = self._purview(ident)
        if turn.guard:
            if not turn.caller:
                # Only reachable with A365_REQUIRE_USER off: Purview policies are per Entra user.
                _log("purview_check", activity="uploadText", result="skipped", reason="no verified Entra user")
                turn.guard = None
            elif _has_attachments(message):
                turn.refusal = FILES_REFUSAL
            else:
                turn.sequence = self._next_sequence(turn.rec.session_id)
                try:
                    allowed = turn.guard.check(turn.caller.oid, text, "uploadText", turn.rec.session_id, turn.sequence)
                    turn.hold_response = allowed and turn.guard.evaluates_inline(turn.caller.oid, "downloadText")
                except Exception as exc:
                    # Fail closed: if Purview can't be asked, don't answer.
                    _log("purview_check", activity="uploadText", result="error", error=str(exc)[:300])
                    allowed = False
                if not allowed:
                    turn.rec.redact()
                    turn.refusal = PURVIEW_REFUSAL
        if turn.caller and ident and not turn.refusal:
            workiq.bind(turn.caller, ident)
        return turn

    def _after(self, turn, error=None) -> bool:
        """Sends telemetry and checks the response. Returns True when Purview blocks the response."""
        blocked = False
        if turn.guard and turn.rec and turn.rec.final_text and error is None:
            try:
                allowed = turn.guard.check(turn.caller.oid, turn.rec.final_text, "downloadText",
                                           turn.rec.session_id, turn.sequence)
            except Exception as exc:
                _log("purview_check", activity="downloadText", result="error", error=str(exc)[:300])
                allowed = not turn.hold_response  # held answers fail closed, streamed ones are already out
            if not allowed:
                if turn.hold_response:
                    blocked = True
                    turn.rec.final_text = PURVIEW_RESPONSE_REFUSAL
                else:
                    _log("purview_check", activity="downloadText",
                         note="policy matched after the answer was streamed (Purview asked for async evaluation)")
        if turn.rec:
            turn.rec.finish(error=error)
        return blocked

    def _refuse(self, turn):
        if turn.rec:
            turn.rec.final_text = turn.refusal
            turn.rec.finish()
        return _refusal_event(turn.session_id, turn.refusal)

    def _create_session_sync(self, user_id):
        return self.create_session(user_id=user_id)["id"]

    # --- query entry points

    def stream_query(self, *, message, user_id, session_id=None, run_config=None, user_token=None, **kwargs):
        turn = self._before(user_id, user_token, session_id, message, "vertex-agent-engine",
                            self._create_session_sync)
        if turn.refusal:
            yield self._refuse(turn)
            return
        held = [] if turn.hold_response else None
        try:
            for event in super().stream_query(message=message, user_id=turn.user_id, session_id=turn.session_id,
                                              run_config=run_config, **kwargs):
                turn.observe(event)
                if held is None:
                    yield event
                else:
                    held.append(event)
        except BaseException as exc:
            self._after(turn, error=exc)
            raise
        if self._after(turn):
            yield _refusal_event(turn.session_id, PURVIEW_RESPONSE_REFUSAL)
        elif held:
            yield from held

    async def async_stream_query(self, *, message, user_id, session_id=None, session_events=None,
                                 run_config=None, user_token=None, **kwargs):
        loop = asyncio.get_running_loop()

        def create_session(uid):
            # Runs in a worker thread; the session service is async, so hop back to the loop.
            return asyncio.run_coroutine_threadsafe(self.async_create_session(user_id=uid), loop).result()["id"]

        turn = await asyncio.to_thread(self._before, user_id, user_token, session_id, message,
                                       "vertex-agent-engine", None if session_events is not None else create_session)
        if turn.refusal:
            yield await asyncio.to_thread(self._refuse, turn)
            return
        held = [] if turn.hold_response else None
        try:
            async for event in super().async_stream_query(message=message, user_id=turn.user_id,
                                                          session_id=turn.session_id, session_events=session_events,
                                                          run_config=run_config, **kwargs):
                turn.observe(event)
                if held is None:
                    yield event
                else:
                    held.append(event)
        except BaseException as exc:
            await asyncio.to_thread(self._after, turn, exc)
            raise
        if await asyncio.to_thread(self._after, turn):
            yield _refusal_event(turn.session_id, PURVIEW_RESPONSE_REFUSAL)
        elif held:
            for event in held:
                yield event

    async def streaming_agent_run_with_events(self, request_json: str):
        # Gemini Enterprise (formerly Agentspace) calls this instead of the query methods above,
        # so it needs the same gates and telemetry. It sends no Entra token, so with
        # A365_REQUIRE_USER=true Gemini Enterprise users are refused.
        req = json.loads(request_json)
        user_id = req.get("user_id") or req.get("userId") or "gemini-enterprise-user"
        session_id = req.get("session_id") or req.get("sessionId")
        turn = await asyncio.to_thread(self._before, user_id, req.pop("user_token", None), session_id,
                                       req.get("message"), "gemini-enterprise", None)
        if turn.refusal:
            refusal = await asyncio.to_thread(self._refuse, turn)
            yield {"events": [dict(refusal, invocation_id="")], "session_id": session_id}
            return
        if turn.caller:
            req["user_id"] = turn.user_id
            req.pop("userId", None)
        try:
            async for response in super().streaming_agent_run_with_events(json.dumps(req)):
                for event in response.get("events", []):
                    turn.observe(event)
                yield response
        except BaseException as exc:
            await asyncio.to_thread(self._after, turn, exc)
            raise
        await asyncio.to_thread(self._after, turn)

    # --- session and memory operations obey the kill switch too

    def _check_enabled(self):
        if not self._gate(self._a365_identity()):
            raise PermissionError(REFUSAL)

    async def _async_check_enabled(self):
        await asyncio.to_thread(self._check_enabled)

    def get_session(self, **kwargs):
        self._check_enabled()
        return super().get_session(**kwargs)

    def list_sessions(self, **kwargs):
        self._check_enabled()
        return super().list_sessions(**kwargs)

    def delete_session(self, **kwargs):
        self._check_enabled()
        return super().delete_session(**kwargs)

    async def async_get_session(self, **kwargs):
        await self._async_check_enabled()
        return await super().async_get_session(**kwargs)

    async def async_list_sessions(self, **kwargs):
        await self._async_check_enabled()
        return await super().async_list_sessions(**kwargs)

    async def async_delete_session(self, **kwargs):
        await self._async_check_enabled()
        return await super().async_delete_session(**kwargs)

    async def async_search_memory(self, **kwargs):
        await self._async_check_enabled()
        return await super().async_search_memory(**kwargs)

    async def async_add_session_to_memory(self, **kwargs):
        await self._async_check_enabled()
        return await super().async_add_session_to_memory(**kwargs)
