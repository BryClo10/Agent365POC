"""Agent 365 bridge for any Google ADK agent hosted on Vertex AI Agent Engine.

Jobs:
  1. Authenticate as the agent's Microsoft Entra *agent identity* (blueprint ->
     agent identity token exchange), using either a Google-issued ID token
     federated to the blueprint (no stored secret) or the blueprint client secret.
  2. Verify who is calling: the caller sends an Entra user access token for the
     blueprint's access_agent_as_user scope, and the bridge checks its signature,
     tenant, audience and scope. The token's object ID is the user from then on.
  3. Act for that user (on-behalf-of) when the agent calls Work IQ MCP tools.
  4. Check prompts and responses against Microsoft Purview (Graph data security APIs).
  5. After every query, send the run to Agent 365 observability as OTLP/HTTP+JSON
     spans: an invoke_agent root plus chat / execute_tool / output_messages
     children, per learn.microsoft.com/microsoft-agent-365/developer/observability-attribute-reference

Uses plain HTTP instead of the Microsoft OpenTelemetry distro because the distro
requires opentelemetry-sdk ~=1.44 while google-adk 2.x pins an older version.

Configuration (environment variables on the Agent Engine deployment):
  A365_TENANT_ID        Entra tenant GUID
  A365_BLUEPRINT_ID     agent identity blueprint appId
  A365_AGENT_ID         agent identity appId (NOT the blueprint appId)
  A365_AGENT_NAME       display name reported in telemetry
  A365_AUTH_MODE        "federated" (Google ID token) or "secret"
  A365_BLUEPRINT_SECRET blueprint client secret (secret mode only; inject via Secret Manager)
  A365_ENFORCE_IDENTITY "true" = fail closed: get a fresh Entra token before every run and
                        refuse to answer if Entra denies it (identity or blueprint disabled,
                        or a Conditional Access policy that blocks this agent identity).
  A365_REQUIRE_USER     "true" = refuse callers that don't send a valid Entra user token.
  A365_PURVIEW          "true" = check prompts (and responses) against Microsoft Purview.
"""

import json
import os
import re
import secrets
import threading
import time
import uuid
from dataclasses import dataclass

import requests

OBS_RESOURCE = "9b975845-388f-4429-889e-eab1ef63949c"
TOKEN_EXCHANGE_AUDIENCE = "api://AzureADTokenExchange"
OBS_BASE = "https://agent365.svc.cloud.microsoft/observabilityService/tenants/{tenant}"
GRAPH = "https://graph.microsoft.com/v1.0"
USER_SCOPE = "access_agent_as_user"
REDACTED = "[withheld: blocked by Microsoft Purview]"
_GUID = re.compile(r"^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$")


def _log(event: str, **fields):
    # Agent Engine forwards stdout to Cloud Logging; one JSON line per event.
    print(json.dumps({"a365": event, **fields}, default=str), flush=True)


def flag(name: str) -> bool:
    return os.environ.get(name, "").lower() == "true"


@dataclass
class Caller:
    """A user whose Entra access token the bridge has verified."""
    oid: str
    upn: str
    name: str
    assertion: str  # the user's token, kept only in memory for on-behalf-of exchanges


class EntraAgentIdentity:
    """Gets tokens as a blueprint-derived agent identity, app-only or on behalf of a user."""

    def __init__(self):
        self.tenant = os.environ["A365_TENANT_ID"]
        self.blueprint_id = os.environ["A365_BLUEPRINT_ID"]
        self.agent_id = os.environ["A365_AGENT_ID"]
        self.mode = os.environ.get("A365_AUTH_MODE", "federated").lower()
        self._cache = {}  # key -> (token, expires_at)
        self._lock = threading.Lock()  # guards _cache only; never held during network calls

    @property
    def _token_url(self):
        return f"https://login.microsoftonline.com/{self.tenant}/oauth2/v2.0/token"

    def _google_id_token(self) -> str:
        # On Agent Engine this comes from the metadata server for the deployment's
        # service account; its "sub" is the service account's unique ID, which is
        # what the blueprint's federated identity credential trusts.
        import google.auth.transport.requests
        import google.oauth2.id_token

        return google.oauth2.id_token.fetch_id_token(
            google.auth.transport.requests.Request(), TOKEN_EXCHANGE_AUDIENCE
        )

    def _post(self, data: dict) -> dict:
        r = requests.post(self._token_url, data=data, timeout=20)
        body = r.json()
        if r.status_code != 200:
            raise RuntimeError(f"token error {r.status_code}: {body.get('error')}: {body.get('error_description', '')[:300]}")
        return body

    def _get_cached(self, key):
        with self._lock:
            hit = self._cache.get(key)
        return hit[0] if hit and time.time() < hit[1] else None

    def _put(self, key, body):
        with self._lock:
            self._cache[key] = (body["access_token"], time.time() + int(body.get("expires_in", 3600)) - 300)
        return body["access_token"]

    def _t1(self) -> str:
        # Step 1: the blueprint authenticates and gets T1, bound to this agent identity (fmi_path).
        step1 = {
            "client_id": self.blueprint_id,
            "scope": f"{TOKEN_EXCHANGE_AUDIENCE}/.default",
            "fmi_path": self.agent_id,
            "grant_type": "client_credentials",
        }
        if self.mode == "secret":
            step1["client_secret"] = os.environ["A365_BLUEPRINT_SECRET"]
        else:
            step1["client_assertion_type"] = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
            step1["client_assertion"] = self._google_id_token()
        return self._post(step1)["access_token"]

    def _app_token(self, scope: str) -> dict:
        # Step 2 (app-only): the agent identity exchanges T1 for a token to the requested resource.
        return self._post({
            "client_id": self.agent_id,
            "scope": scope,
            "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
            "client_assertion": self._t1(),
            "grant_type": "client_credentials",
        })

    def app_token(self, scope: str) -> str:
        return self._get_cached(("app", scope)) or self._put(("app", scope), self._app_token(scope))

    def token(self) -> str:
        """Agent 365 observability token."""
        return self.app_token(f"{OBS_RESOURCE}/.default")

    def graph_token(self) -> str:
        """Microsoft Graph token for the agent identity, used for the Purview APIs."""
        return self.app_token("https://graph.microsoft.com/.default")

    def obo_token(self, caller: Caller, scope: str) -> str:
        """Token for `scope` as this agent identity acting for `caller` (Entra Agent ID on-behalf-of flow)."""
        key = ("obo", caller.oid, scope)
        cached = self._get_cached(key)
        if cached:
            return cached
        body = self._post({
            "client_id": self.agent_id,
            "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
            "client_assertion": self._t1(),
            "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
            "assertion": caller.assertion,
            "requested_token_use": "on_behalf_of",
            "scope": scope,
        })
        _log("obo_token_acquired", user=caller.oid, scope=scope)
        return self._put(key, body)

    def authorize(self) -> bool:
        """Enforce mode: ask Entra for a fresh token before every run (no cache), so
        disabling the agent identity, disabling its blueprint or a Conditional Access
        policy that blocks this agent identity stops the agent on its next query.
        The fresh token is reused for telemetry."""
        scope = f"{OBS_RESOURCE}/.default"
        try:
            self._put(("app", scope), self._app_token(scope))
            _log("identity_check", allowed=True, agent_id=self.agent_id)
            return True
        except Exception as exc:
            with self._lock:
                self._cache.clear()
            _log("identity_check", allowed=False, agent_id=self.agent_id, error=str(exc)[:500])
            return False


class UserVerifier:
    """Verifies Entra user access tokens issued for the blueprint's access_agent_as_user scope."""

    def __init__(self, identity: EntraAgentIdentity):
        self.tenant = identity.tenant
        self.audience = identity.blueprint_id
        self._jwks = None

    def verify(self, token: str) -> Caller:
        import jwt  # PyJWT

        if self._jwks is None:
            self._jwks = jwt.PyJWKClient(
                f"https://login.microsoftonline.com/{self.tenant}/discovery/v2.0/keys", lifespan=3600)
        key = self._jwks.get_signing_key_from_jwt(token).key
        claims = jwt.decode(
            token, key, algorithms=["RS256"], leeway=60,
            audience=[self.audience, f"api://{self.audience}"],
            issuer=f"https://login.microsoftonline.com/{self.tenant}/v2.0",
            options={"require": ["exp", "iat", "oid", "tid"]})
        if claims["tid"] != self.tenant:
            raise PermissionError("token is from another tenant")
        if USER_SCOPE not in claims.get("scp", "").split():
            raise PermissionError(f"token lacks the {USER_SCOPE} scope (app-only tokens are not accepted)")
        return Caller(oid=claims["oid"], upn=claims.get("preferred_username") or claims.get("upn", ""),
                      name=claims.get("name", ""), assertion=token)


class PurviewGuard:
    """Checks prompts and responses against Microsoft Purview policies through Microsoft Graph,
    per learn.microsoft.com/purview/developer/use-the-api and
    learn.microsoft.com/graph/security-datasecurityandgovernance-overview."""

    SCOPE_TTL = 3600       # Purview reports scope changes on processContent, so cached scopes can live an hour.
    EMPTY_SCOPE_TTL = 300  # "No policy applies" gets no such signal, so recheck it every 5 minutes.

    def __init__(self, identity: EntraAgentIdentity):
        self.identity = identity
        self.app = os.environ.get("A365_AGENT_NAME", "vertex-agent")
        self.location = {"@odata.type": "microsoft.graph.policyLocationApplication", "value": identity.agent_id}
        self._scopes = {}  # user -> (fetched_at, etag, scopes)
        self._lock = threading.Lock()

    def _headers(self, etag=None):
        h = {"Authorization": f"Bearer {self.identity.graph_token()}", "Content-Type": "application/json"}
        if etag:
            h["If-None-Match"] = etag
        return h

    def _user_scopes(self, user, refresh=False):
        with self._lock:
            cached = self._scopes.get(user)
        ttl = self.SCOPE_TTL if cached and cached[2] else self.EMPTY_SCOPE_TTL
        if cached and not refresh and time.time() - cached[0] < ttl:
            return cached[1], cached[2]
        r = requests.post(f"{GRAPH}/users/{user}/dataSecurityAndGovernance/protectionScopes/compute",
                          headers=self._headers(), timeout=20,
                          json={"activities": "uploadText,downloadText", "locations": [self.location]})
        r.raise_for_status()
        entry = (time.time(), r.headers.get("ETag"), r.json().get("value", []))
        with self._lock:
            self._scopes[user] = entry
        return entry[1], entry[2]

    @staticmethod
    def _applicable(scopes, activity):
        return [s for s in scopes
                if activity.lower() in [a.strip().lower() for a in s.get("activities", "").split(",")]]

    def evaluates_inline(self, user, activity) -> bool:
        """True when Purview wants this activity held until processContent answers."""
        _, scopes = self._user_scopes(user)
        return any(s.get("executionMode") == "evaluateInline" for s in self._applicable(scopes, activity))

    def _body(self, text, activity, correlation_id, sequence, device=True):
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        body = {
            "contentEntries": [{
                "@odata.type": "microsoft.graph.processConversationMetadata",
                "identifier": str(uuid.uuid4()),
                "content": {"@odata.type": "microsoft.graph.textContent", "data": text},
                "name": f"{self.app} {'prompt' if activity == 'uploadText' else 'response'}",
                "correlationId": correlation_id, "sequenceNumber": sequence, "isTruncated": False,
                "createdDateTime": now, "modifiedDateTime": now}],
            "activityMetadata": {"activity": activity},
            "protectedAppMetadata": {"name": self.app, "version": "1.0", "applicationLocation": self.location},
            "integratedAppMetadata": {"name": self.app, "version": "1.0"},
        }
        if device:
            body["deviceMetadata"] = {"deviceType": "Unmanaged", "operatingSystemSpecifications": {
                "operatingSystemPlatform": "Google Vertex AI Agent Engine", "operatingSystemVersion": "1"}}
        return body

    def _process(self, user, etag, body) -> dict:
        r = requests.post(f"{GRAPH}/users/{user}/dataSecurityAndGovernance/processContent",
                          headers=self._headers(etag), timeout=20, json={"contentToProcess": body})
        r.raise_for_status()
        # 202 Accepted and 204 No Content carry no body and no policy actions.
        result = r.json() if r.status_code == 200 and r.content else {}
        if result.get("protectionScopeState") == "modified":
            self._user_scopes(user, refresh=True)
        return result

    def _audit(self, user, etag, body):
        # Audit only: a failure here must never block the user.
        payload = {"contentMetadata": body, "userId": user}
        if etag:
            payload["scopeIdentifier"] = etag
        try:
            r = requests.post(f"{GRAPH}/users/{user}/dataSecurityAndGovernance/activities/contentActivities",
                              headers=self._headers(), timeout=20, json=payload)
            return r.status_code, None if r.ok else r.text[:300]
        except Exception as exc:
            return "error", str(exc)[:300]

    def check(self, user, text, activity, correlation_id, sequence) -> bool:
        """Returns False when Purview says to block. Raises when Purview can't be asked."""
        etag, scopes = self._user_scopes(user)
        applicable = self._applicable(scopes, activity)
        if not applicable:
            # No policy covers this user and activity: record it for audit only.
            status, error = self._audit(user, etag, self._body(text, activity, correlation_id, sequence, device=False))
            _log("purview_check", activity=activity, result="allowed", policies="none apply",
                 audit_logged=status, audit_error=error)
            return True
        if any(s.get("executionMode") == "evaluateOffline"
               and any(a.get("action") == "restrictAccess" for a in s.get("policyActions", []))
               for s in applicable):
            # Docs: evaluateOffline + restrictAccess means restrict now, and still send the content.
            try:
                self._process(user, etag, self._body(text, activity, correlation_id, sequence))
            except Exception as exc:
                _log("purview_check", activity=activity, note="processContent failed after offline block",
                     error=str(exc)[:300])
            _log("purview_check", activity=activity, result="blocked", reason="protection scope restricts access")
            return False
        result = self._process(user, etag, self._body(text, activity, correlation_id, sequence))
        blocked = any(a.get("action") == "restrictAccess" and a.get("restrictionAction", "block") == "block"
                      for a in result.get("policyActions", []))
        _log("purview_check", activity=activity, result="blocked" if blocked else "allowed",
             policy_actions=result.get("policyActions", []), errors=result.get("processingErrors", []))
        return not blocked


def _attr(key, value):
    return {"key": key, "value": {"stringValue": str(value)}}


def _now_ns() -> int:
    return time.time_ns()


class RunRecorder:
    """Collects one agent run from ADK events and ships it as an OTLP trace."""

    def __init__(self, identity: EntraAgentIdentity, caller, session_id, message, channel="vertex-agent-engine",
                 mcp_tools=None):
        self.identity = identity
        self.caller = caller
        self.channel = channel
        self.session_id = session_id or str(uuid.uuid4())
        self.message = message if isinstance(message, str) else json.dumps(message, default=str)
        self.trace_id = secrets.token_hex(16)
        self.root_id = secrets.token_hex(8)
        self.start = _now_ns()
        self.children = []
        self.pending_tools = {}
        self.final_text = ""
        self.model = os.environ.get("A365_MODEL_NAME", "gemini-2.5-flash")
        self.mcp_tools = mcp_tools if mcp_tools is not None else {}
        self._chat_start = self.start
        self._chat_input = [{"role": "user", "content": self.message}]
        self._sent = False

    def redact(self):
        """Blocked content must not be copied into telemetry."""
        self.message = REDACTED
        self._chat_input = [{"role": "user", "content": REDACTED}]

    def _common(self):
        return [
            _attr("microsoft.tenant.id", self.identity.tenant),
            _attr("gen_ai.conversation.id", self.session_id),
            _attr("microsoft.session.id", self.session_id),
            _attr("microsoft.channel.name", self.channel),
            _attr("gen_ai.agent.id", self.identity.agent_id),
            _attr("gen_ai.agent.name", os.environ.get("A365_AGENT_NAME", "vertex-agent")),
            _attr("microsoft.a365.agent.blueprint.id", self.identity.blueprint_id),
        ]

    @staticmethod
    def _network():
        # The caller's IP never reaches Agent Engine, so use the placeholder the spec suggests.
        return [_attr("client.address", "0.0.0.0"), _attr("server.address", "aiplatform.googleapis.com"),
                _attr("server.port", "443")]

    def _span(self, name, start, end, attrs, parent=None, span_id=None, error=None):
        status = {"code": 2, "message": error[:500]} if error else {"code": 1}
        network = self._network() if name != "output_messages" else []
        return {
            "traceId": self.trace_id,
            "spanId": span_id or secrets.token_hex(8),
            "parentSpanId": parent or "",
            "name": name,
            "kind": 1,
            "startTimeUnixNano": str(start),
            "endTimeUnixNano": str(end),
            "status": status,
            "attributes": [_attr("gen_ai.operation.name", name)] + attrs + network + self._common(),
        }

    def _chat(self, start, end, usage, output):
        return self._span("chat", start, end, [
            _attr("gen_ai.request.model", self.model),
            _attr("gen_ai.provider.name", "gcp.vertex_ai"),
            _attr("gen_ai.usage.input_tokens", usage.get("prompt_token_count", 0)),
            _attr("gen_ai.usage.output_tokens", usage.get("candidates_token_count", 0)),
            _attr("gen_ai.input.messages", json.dumps(self._chat_input, default=str)),
            _attr("gen_ai.output.messages", json.dumps(output, default=str)),
        ], parent=self.root_id)

    def observe(self, event: dict):
        """Feed each ADK event (dict form, as yielded by AdkApp.stream_query)."""
        now = _now_ns()
        usage = event.get("usage_metadata") or {}
        calls = []
        for part in (event.get("content") or {}).get("parts", []) or []:
            if part.get("function_call"):
                calls.append(part["function_call"])
            elif part.get("function_response"):
                fr = part["function_response"]
                key = fr.get("id") or fr.get("name")
                fc, started = self.pending_tools.pop(key, ({"name": fr.get("name"), "args": {}}, now))
                server = self.mcp_tools.get(fc.get("name"))
                attrs = [
                    _attr("gen_ai.tool.name", fc.get("name")),
                    _attr("gen_ai.tool.type", "MCP Server" if server else "function"),
                    _attr("gen_ai.tool.call.id", key),
                    _attr("gen_ai.tool.call.arguments", json.dumps(fc.get("args", {}), default=str)),
                    _attr("gen_ai.tool.call.result", json.dumps(fr.get("response", {}), default=str)),
                ]
                if server:
                    attrs.append(_attr("gen_ai.tool.server.name", server))
                self.children.append(self._span("execute_tool", started, now, attrs, parent=self.root_id))
                self._chat_input = [{"role": "tool", "name": fc.get("name"), "content": fr.get("response", {})}]
                self._chat_start = now
            elif part.get("text"):
                self.final_text += part["text"]
                self.children.append(self._chat(self._chat_start, now, usage,
                                                [{"role": "assistant", "content": part["text"]}]))
                self._chat_start = now
        if calls:
            # One model turn that asked for one or more tools is one chat span.
            self.children.append(self._chat(self._chat_start, now, usage,
                                            [{"role": "assistant", "tool_calls": calls}]))
            for fc in calls:
                self.pending_tools[fc.get("id") or fc.get("name")] = (fc, now)

    def finish(self, error=None):
        if self._sent:
            return
        self._sent = True
        end = _now_ns()
        output = json.dumps([{"role": "assistant", "content": self.final_text}])
        self.children.append(self._span("output_messages", end - 1_000_000, end, [
            _attr("gen_ai.output.messages", output),
        ], parent=self.root_id))
        root_attrs = [
            _attr("gen_ai.execution.type", "HumanToAgent"),
            _attr("gen_ai.input.messages", json.dumps([{"role": "user", "content": self.message}])),
            _attr("gen_ai.output.messages", output),
        ]
        if self.caller:
            root_attrs += [_attr("user.id", self.caller.oid), _attr("user.email", self.caller.upn),
                           _attr("user.name", self.caller.name)]
        root = self._span("invoke_agent", self.start, end, root_attrs, span_id=self.root_id,
                          error=str(error) if error else None)
        body = {"resourceSpans": [{
            "resource": {"attributes": [_attr("service.name", os.environ.get("A365_AGENT_NAME", "vertex-agent"))]},
            "scopeSpans": [{"scope": {"name": "vertex-a365-bridge", "version": "2.0.0"},
                            "spans": [root] + self.children}],
        }]}
        self._send(body)

    def _send(self, body):
        url = (OBS_BASE.format(tenant=self.identity.tenant)
               + f"/otlp/agents/{self.identity.agent_id}/traces?api-version=1")
        try:
            r = requests.post(url, json=body, timeout=20, headers={
                "Authorization": f"Bearer {self.identity.token()}",
                "Content-Type": "application/json",
            })
            summary = {}
            try:
                for res in r.json().get("results", []):
                    for sink, outcome in (res.get("sinks") or {}).items():
                        k = f"{sink}:{outcome.get('status')}" + (f"({outcome.get('reason')})" if outcome.get("reason") else "")
                        summary[k] = summary.get(k, 0) + 1
            except ValueError:
                pass
            _log("telemetry_sent", http=r.status_code, spans=len(body["resourceSpans"][0]["scopeSpans"][0]["spans"]),
                 trace_id=self.trace_id, conversation=self.session_id, results=summary,
                 body=None if r.ok else r.text[:500])
        except Exception as exc:  # telemetry must never break the agent
            _log("telemetry_error", error=str(exc)[:500], trace_id=self.trace_id)


def check_eligibility(identity: EntraAgentIdentity) -> dict:
    r = requests.get(OBS_BASE.format(tenant=identity.tenant) + "/eligibility?api-version=1",
                     headers={"Authorization": f"Bearer {identity.token()}"}, timeout=20)
    return {"http": r.status_code, "body": r.text[:300]}
