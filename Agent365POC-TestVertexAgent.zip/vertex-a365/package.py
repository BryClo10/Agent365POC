"""Build vertex-a365.zip for a colleague from an allowlist, so local settings, deployment
records and CLI output (which holds a blueprint client secret) can never ship by accident.

Usage:
    python package.py [output.zip]
"""

import pathlib
import sys
import zipfile

HERE = pathlib.Path(__file__).parent
INCLUDE = [
    "RUNBOOK.md",
    "deploy.py",
    "diagnose.py",
    "package.py",
    "a365_vertex_bridge/*.py",
    "calculator_agent/*.py",
    "policy_agent/*.py",
    "docs/screenshots/*.jpg",
    "Vertex Agents in Agent 365 - Runbook.docx",
]
NEVER = ("a365-cli", "a365-settings", "deployments", ".venv", "__pycache__", "CLEANUP-LEDGER.md")

out = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else HERE.parent / "vertex-a365.zip")
files = sorted({p for pattern in INCLUDE for p in HERE.glob(pattern)})
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for path in files:
        rel = path.relative_to(HERE)
        if any(part in NEVER for part in rel.parts):
            sys.exit(f"Refusing to package {rel}")
        z.write(path, pathlib.Path("vertex-a365") / rel)
        print("  added", rel)
print(f"Wrote {out} ({len(files)} files)")
