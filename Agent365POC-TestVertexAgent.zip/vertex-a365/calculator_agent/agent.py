"""Minimal Google ADK agent used to validate the Vertex AI -> Agent 365 runbook.

Deliberately tiny: two deterministic tools so a test query always produces
one model call plus one tool call, which is easy to spot in telemetry.
"""

from google.adk.agents import Agent


def add(a: float, b: float) -> dict:
    """Add two numbers and return the sum."""
    return {"result": a + b}


def commission(sale_price: float, rate_percent: float) -> dict:
    """Calculate the commission earned on a sale at the given percentage rate."""
    return {"commission": round(sale_price * rate_percent / 100, 2)}


root_agent = Agent(
    name="vertex_calculator",
    model="gemini-2.5-flash",
    description="Adds numbers and calculates sales commission.",
    instruction=(
        "You are a calculator. Always use the add or commission tools for arithmetic "
        "and answer with the tool result in one short sentence."
    ),
    tools=[add, commission],
)
