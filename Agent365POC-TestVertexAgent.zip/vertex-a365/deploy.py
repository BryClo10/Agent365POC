"""Deploy, update, query or delete an ADK agent on Vertex AI Agent Engine.

Each agent is a Python package in this folder (calculator_agent/, policy_agent/)
exposing `root_agent`. The Google Cloud project and region come from the
GCP_PROJECT and GCP_REGION environment variables.

The agent is deployed with the Agent 365 bridge (identity + telemetry) when either
  - a365-settings/<agent name>.json exists, or
  - a365-cli/<agent name>/ holds a completed `a365 setup all` run,
otherwise it's deployed as a plain Vertex agent, i.e. what a not-yet-onboarded agent looks like.

Work IQ MCP tools are added when a365-cli/<agent name>/ToolingManifest.json or
a365-settings/<agent name>.ToolingManifest.json exists (written by `a365 develop add-mcp-servers`).

Security switches (set them in the PowerShell window before create or update; "true" or "false"):
  A365_PURVIEW        check prompts and answers against Microsoft Purview
  A365_REQUIRE_USER   refuse callers that don't send an Entra user token (default true)
On update, a switch you don't set keeps the value the deployed agent already has.

The resource name of each agent is remembered in deployments/<agent name>.txt, so
later commands take the agent name instead of the full resource name.

Usage:
    python deploy.py create <package> <agent name>
    python deploy.py update <package> <agent name> [resource name]
    python deploy.py query  <agent name> "question"                 (signs in as your az login)
    python deploy.py query  <agent name> "question" --no-sign-in [user id]
    python deploy.py delete <agent name or resource name>
"""

import importlib
import json
import os
import pathlib
import subprocess
import sys

import vertexai
from vertexai import agent_engines

try:
    PROJECT = os.environ["GCP_PROJECT"]
    LOCATION = os.environ["GCP_REGION"]
except KeyError as missing:
    sys.exit(f"Set {missing} first (runbook step 3), for example $env:GCP_PROJECT = \"my-project\".")
STAGING_BUCKET = f"gs://{PROJECT}-staging"
# Every agent in the project runs as this service account. The Entra blueprint's
# federated credential trusts it, so any onboarded agent can get its token.
SERVICE_ACCOUNT = f"a365-agent@{PROJECT}.iam.gserviceaccount.com"

# Pinned to the versions validated together: aiplatform 1.165 needs google-adk 2.x
# (older ADK fails with "Runner.__init__() got an unexpected keyword argument"), and the
# Agent 365 tooling gateway rejects the MCP 2.x client's protocol version.
REQUIREMENTS = [
    "google-cloud-aiplatform[agent_engines,adk]==1.165.1",
    "google-adk==2.10.0",
    "mcp==1.30.0",
    "pyjwt[crypto]==2.15.1",
    "requests",
]
SWITCHES = {"A365_PURVIEW": "false", "A365_REQUIRE_USER": "true"}

HERE = pathlib.Path(__file__).parent
DEPLOYMENTS = HERE / "deployments"
client = vertexai.Client(project=PROJECT, location=LOCATION)


def _read_json(path: pathlib.Path):
    # utf-8-sig: files written by Windows PowerShell may start with a byte order mark.
    return json.loads(path.read_text(encoding="utf-8-sig"))


def a365_settings(name: str):
    path = HERE / "a365-settings" / f"{name}.json"
    if path.exists():
        return _read_json(path)
    cli = HERE / "a365-cli" / name
    generated, config = cli / "a365.generated.config.json", cli / "a365.config.json"
    if generated.exists() and config.exists():
        ids, cfg = _read_json(generated), _read_json(config)
        if ids.get("agenticAppId"):
            return {
                "A365_TENANT_ID": cfg["tenantId"],
                "A365_BLUEPRINT_ID": ids["agentBlueprintId"],
                "A365_AGENT_ID": ids["agenticAppId"],
                "A365_AGENT_NAME": name,
                "A365_AUTH_MODE": "federated",
                "A365_ENFORCE_IDENTITY": "true",
            }
    return None


def tooling_manifest(name: str):
    for path in (HERE / "a365-cli" / name / "ToolingManifest.json",
                 HERE / "a365-settings" / f"{name}.ToolingManifest.json"):
        if path.exists():
            return _read_json(path).get("mcpServers", [])
    return []


def remember(name: str, resource: str):
    DEPLOYMENTS.mkdir(exist_ok=True)
    (DEPLOYMENTS / f"{name}.txt").write_text(resource)


def resolve(name_or_resource: str) -> str:
    if name_or_resource.startswith("projects/"):
        return name_or_resource
    saved = DEPLOYMENTS / f"{name_or_resource}.txt"
    if not saved.exists():
        sys.exit(f"No saved resource name for '{name_or_resource}'. Create the agent first, "
                 f"or pass its full resource name (projects/.../reasoningEngines/...).")
    return saved.read_text().strip()


def deployed_env(resource: str) -> dict:
    spec = client.agent_engines.get(name=resource).api_resource.spec
    env = getattr(getattr(spec, "deployment_spec", None), "env", None) or []
    return {e.name: e.value for e in env}


def build(package: str, display_name: str, current_env=None):
    root_agent = importlib.import_module(package).root_agent
    settings = a365_settings(display_name)
    env = {"GOOGLE_CLOUD_AGENT_ENGINE_ENABLE_TELEMETRY": "true"}
    extra = [package]
    if settings:
        from a365_vertex_bridge import A365AdkApp

        env.update(settings)
        for switch, default in SWITCHES.items():
            if os.environ.get(switch):
                env[switch], source = os.environ[switch].lower(), "set in this window"
            elif current_env and switch in current_env:
                env[switch], source = current_env[switch], "kept from the deployed agent"
            else:
                env[switch], source = default, "default"
            print(f"  {switch} = {env[switch]} ({source})")
        servers = tooling_manifest(display_name)
        if servers:
            from a365_vertex_bridge.workiq import WorkIQToolset

            root_agent.tools.append(WorkIQToolset(servers))
            print(f"  Work IQ tools: {', '.join(s['mcpServerName'] for s in servers)}")
        app = A365AdkApp(agent=root_agent)
        extra.append("a365_vertex_bridge")
        print(f"Deploying WITH Agent 365 bridge as agent identity {settings['A365_AGENT_ID']}")
    else:
        app = agent_engines.AdkApp(agent=root_agent)
        print("Deploying as a plain Vertex agent (not onboarded to Agent 365)")
    config = {
        "display_name": display_name,
        "description": f"{display_name} (ADK agent on Vertex AI Agent Engine)",
        "requirements": REQUIREMENTS,
        "extra_packages": extra,
        "staging_bucket": STAGING_BUCKET,
        "service_account": SERVICE_ACCOUNT,
        "env_vars": env,
    }
    return app, config


def user_token(name: str) -> str:
    """Entra access token for the agent, for whoever is signed in to the Azure CLI."""
    settings = a365_settings(name)
    if not settings:
        sys.exit(f"'{name}' isn't onboarded to Agent 365, so there's nothing to sign in to.")
    scope = f"api://{settings['A365_BLUEPRINT_ID']}/access_agent_as_user"
    az = "az.cmd" if os.name == "nt" else "az"
    return subprocess.run([az, "account", "get-access-token", "--scope", scope, "--query", "accessToken", "-o", "tsv"],
                          check=True, capture_output=True, text=True).stdout.strip()


def query(resource: str, text: str, user_id: str, token=None):
    remote = client.agent_engines.get(name=resource)
    kwargs = {"user_token": token} if token else {}
    for event in remote.stream_query(user_id=user_id, message=text, **kwargs):
        for part in event.get("content", {}).get("parts", []):
            if "text" in part:
                print("AGENT:", part["text"])
            elif "function_call" in part:
                print("TOOL CALL:", part["function_call"].get("name"), part["function_call"].get("args"))


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "create":
        app, config = build(sys.argv[2], sys.argv[3])
        remote = client.agent_engines.create(agent=app, config=config)
        remember(sys.argv[3], remote.api_resource.name)
        print("RESOURCE:", remote.api_resource.name)
    elif cmd == "update":
        resource = sys.argv[4] if len(sys.argv) > 4 else resolve(sys.argv[3])
        app, config = build(sys.argv[2], sys.argv[3], current_env=deployed_env(resource))
        remote = client.agent_engines.update(name=resource, agent=app, config=config)
        remember(sys.argv[3], remote.api_resource.name)
        print("UPDATED:", remote.api_resource.name)
    elif cmd == "query":
        name, question, rest = sys.argv[2], sys.argv[3], sys.argv[4:]
        if rest[:1] == ["--no-sign-in"]:
            query(resolve(name), question, rest[1] if len(rest) > 1 else "runbook-test")
        else:
            query(resolve(name), question, "signed-in-user", token=user_token(name))
    elif cmd == "delete":
        print("This permanently deletes the agent, its sessions and its memory in Vertex AI.")
        client.agent_engines.delete(name=resolve(sys.argv[2]), force=True)
        print("DELETED")
